const carro=new Carrito();
const carrito = document.getElementById('carrito');
const productos =document.getElementById('lista-productos');    
const listaProductos =document.getElementById('lista-carrito')
const procesarPedidobtn = document.getElementById('iracompra')

cargarEventos();
function cargarEventos(){
    productos.addEventListener('click',(e)=>{carro.comprarProducto(e)});
    carrito.addEventListener('click',(e)=>{carro.eliminarProducto(e)});
    document.addEventListener('DOMContentLoaded',carro.AccesoArrayLocal());
    procesarPedidobtn.addEventListener('click',(e)=>{carro.procesarPedido(e)});
}